const path = require('path')
const http = require('http')
const express = require('express')
const fs = require('fs')
const socketio = require('socket.io')

const readTenLines = require(path.join(__dirname + '/fileReaderHelper.js'))

const app = express()
const server = http.createServer(app)
const io = socketio(server)

app.use(express.static(path.join(__dirname, '../public')))
const path_of_file_to_watch = path.join(__dirname + '/watchMe.txt')

// let md5Previous = null
let fsWait = false
fs.watch(path_of_file_to_watch, (event, filename) => {
  if (filename) {
    if (fsWait) return
    fsWait = setTimeout(() => {
      fsWait = false
    }, 100)
		// const md5Current = md5(fs.readFileSync(buttonPressesLogFile))
    // if (md5Current === md5Previous) {
    //   return
    // }
    // md5Previous = md5Current

    readTenLines(path_of_file_to_watch)
    	.then((lines) => io.emit('fileUpdated', lines.split('\n')))
  }
})

io.on('connection', (socket) => {
  console.log('New websocket connected')
	readTenLines(path_of_file_to_watch)
		.then((lines) => socket.emit('fileUpdated', lines.split('\n')))
})

server.listen(4000, () => console.log('Server listening for changes to log file!'))
