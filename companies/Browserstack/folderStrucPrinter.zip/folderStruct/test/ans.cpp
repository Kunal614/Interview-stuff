#include<bits/stdc++.h>
using namespace std;
#define FASTIO ios_base::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL);
#define ll long long
#define vll vector<long long>
#define vint vector<int>
#define all(p) p.begin(), p.end()
#define fori(n) for(int i=0;i<n;i++) cin>>
#define loop(i,j,n) for(int i=j;i<n;i++)

bool solve (int x, int y, int k, int n) {
    if(x == y) return true;
    if(x + k > n && x - k < 0)  return false;
    set<pair<int, int>> s;
    int xd = 1, yd = 1;
    while(1) {
        if(x == y) {
            return true;
        }
        if(xd == 1) {
            if(x + k > n) {
                x -= k;
                xd = 0;
            } else {
                x += k;
            }
        } else {
            if(x - k < 0) {
                x += k;
                xd = 1;
            } else {
                x -= k;
            }
        }
        if(yd == 1) {
            if(y + k > n) {
                y -= k;
                yd = 0;
            } else {
                y += k;
            }
        } else {
            if(y - k < 0) {
                y += k;
                yd = 1;
            } else {
                y -= k;
            }
        }
        pair<int, int> p = make_pair(x,y);
        if(s.find(p) != s.end()) {
            return false;
        } else {
            s.insert(p);
        }
    }
}

int main() {
    FASTIO;
    int t;
    cin>>t;
    while(t-- > 0){
        int x,y,k,n;
        cin>>x>>y>>k>>n;
        bool flag = solve(x,y,k,n);
        
        if(flag) {
            cout<<"Yes\n";
        } else {
            cout<<"No\n";
        }
    }
	return 0;
}
