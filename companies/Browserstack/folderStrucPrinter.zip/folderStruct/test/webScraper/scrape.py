from bs4 import BeautifulSoup
import requests

n=int(input('Enter N (max. 1000): '))

print('\nPlease wait...')

all_movies = []

#two cases because imdb shows at most 250 movies at once
if(n <= 250):
	url = f'https://www.imdb.com/search/title/?count={n}&groups=top_1000&sort=user_rating,desc&start=1'
	source = requests.get(url).text
	soup = BeautifulSoup(source, 'lxml') #lxml is an HTML parser
	all_movies = soup.find_all('div', class_='lister-item-content')

else:
	start = 1
	tempn = n
	while(tempn > 0):
		count = min(tempn, 250)
		url = f'https://www.imdb.com/search/title/?count={count}&groups=top_1000&sort=user_rating,desc&start={start}'
		tempn -= 250
		start += 250
		source = requests.get(url).text
		soup = BeautifulSoup(source, 'lxml') #lxml is an HTML parser
		movies = soup.find_all('div', class_='lister-item-content')
		all_movies.extend(movies)


#database is a dictionary for holding the information for queries
database = {}

for movie in all_movies:
	moviename = movie.h3.a.text
	rank = movie.h3.span.text
	rank = rank[:-1]
	people = movie.find('p', class_='')

	#find the names of stars for each movie
	stars = str(people).split('Stars:')[1]
	stars = stars[:-4]
	stars = stars.split(',')
	
	starList = []
	for star in stars:
		pos1 = -1
		pos2 = -1
		for i in range(len(star)):
			if(star[i] == '>'):
				pos1 = i
				while(star[i] != '<'): 
					i = i+1
				pos2 = i
				eachStar = star[pos1+1:pos2]
				starList.append(eachStar)
				break

	#building the knowledge base
	for star in starList:
		if star in database.keys():
			database[star].append(f'{moviename} (#{rank})')
		else:
			movarr = []
			movarr.append(f'{moviename} (#{rank})')
			database[star] = movarr

#knowledge base ready
print('Data Fetched...\n')

#itr for multiple queries
itr = 1
while(itr):
	print()
	name=input('Enter Actor Name: ')
	m=int(input('Enter M: '))

	print()

	actor_movies = database.get(name, [])

	if len(actor_movies) == 0:
		print(f'{name} has not worked in any of the top {n} movies')
	else:
		count = min(m, len(actor_movies))
		if(m < len(actor_movies)):
			print(f'{name}\'s top {m} movies out of the top {n} movies are:')
		else: 
			print(f'{name} has worked in {count} movie(s) out of the top {n} movies. They are:')
		for x in range(count):
			print(actor_movies[x])
	print()

	itr=int(input('Enter 1 to continue, 0 to quit: '))

print()