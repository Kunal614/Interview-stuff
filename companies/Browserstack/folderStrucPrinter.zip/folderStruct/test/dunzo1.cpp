#include <bits/stdc++.h>
using namespace std;

#define int int64_t

int n , m;
const int MXN = 105;
int a[MXN][MXN];
int dp[MXN][MXN][MXN]; // r1 c1 r2
int rec(int r1 , int c1 , int r2) { 
    int &ret = dp[r1][c1][r2];
    
    if(ret != -1) 
        return ret;
    
    int c2 = r1 + c1 - r2;
    int add = a[r1][c1] + a[r2][c2];
    if(r2 == r1 && c1 == c2) 
        add = a[r1][c1];
        
    if(r1 == n && c1 == m) {
        assert(r2 ==n && c2 == m);
        return ret = a[n][m] == 1;
    }
    ret = INT_MIN;
    vector<vector<int>> vv = {{1 , 0 , 1} , {0 , 1 , 1} , {1 , 0 , 0} , {0 , 1 , 0} };
    for(auto &v : vv) {
        int tr1 = r1 + v[0];
        int tc1 = c1 + v[1];
        int tr2 = r2 + v[2];
        int tc2 = tr1 + tc1 - tr2;
        if(tr1 <= n && tc1 <= m && tr2 <= n && tc2 <= m) {
            if(a[tr1][tc1] == -1 || a[tr2][tc2] == -1) 
                continue; 
            ret = max(ret , add + rec(tr1 , tc1 , tr2)  );
        }
    }
    return ret;
}
void solve()
{
    memset(dp , -1 ,sizeof dp);
    
    cin >> n >> m;
    for(int i = 1; i <= n; ++i) {
        for(int j = 1; j <= m; ++j) {
            cin >> a[i][j];
        }
    }
    cout << rec( 1 , 1 , 1) << endl;
}

signed main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
        solve();
};77