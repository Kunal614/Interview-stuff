#include <bits/stdc++.h>
using namespace std;

#define FASTIO ios_base::sync_with_stdio(false),cin.tie(NULL),cout.tie(NULL)

string get_ans (string s, int n) {
    string result = "";

    for(int i=0;i<s.size();i++) {
        int pos = i;
        char c = s[i];
        while(i < s.size() && s[i] == c) i++;
        if(i-pos != n) 
        result += s.substr(pos, i-pos);
        --i;
    }

    return result;
}

int main()
{
    string s;
    cin>>s;
    int n;
    cin>>n;

    cout<<get_ans(s, n)<<"\n";

    return 0;
}