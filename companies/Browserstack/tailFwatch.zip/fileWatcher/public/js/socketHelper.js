const socket = io()

const createListFromArr = ipArr => {
  let list = document.createElement('ul')

  for (var i = 0; i < ipArr.length; i++) {
        var item = document.createElement('li')
        item.appendChild(document.createTextNode(ipArr[i]))
        list.appendChild(item)
    }

  return list
}

socket.on('fileUpdated', (lastTenLines) => {
  let listUL = document.getElementById('lastTen')
  let parent = listUL.parentNode
  let newListUL = createListFromArr(lastTenLines)

  parent.insertBefore(
    newListUL,
    listUL
  )

  parent.removeChild(listUL)
  newListUL.id = 'lastTen'

  // let listdiv = document.getElementById('lastTen')
  // listdiv.innerHTML = ""
  // listdiv.appendChild(createListFromArr(lastTenLines))
})
