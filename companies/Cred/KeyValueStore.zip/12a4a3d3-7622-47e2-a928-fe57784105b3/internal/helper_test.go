package internal

// TODO : unit tests. As the project was intitally in java so it's not support monkey.patch for golang. Some configs needs to be changed for the project
//import (
//	"github.com/monkey"
//	"testing"
//)

//func TestCheckKeyExists(t *testing.T) {
//	defer monkey.Patch(kvBase.GetAttrTypeMap(), func() {
//		return
//	}).Unpatch()
//	CheckKeyExists("hell")
//}
