const PATH = require('path')
const FS = require('fs')
const prompt = require('prompt-sync')() //for taking user input

//define the structure of each node
class TreeNode {
  constructor(path) {
    this.path = path
    this.name = PATH.basename(path)
    this.children = []
  }
}

//function take takes path as input and returns a json object representing the folder structure
// DFS algorithm
const  buildTree = (rootPath) => {
  const root = new TreeNode(rootPath)

  const stack = [root]

  while (stack.length) {
    const currentNode = stack.pop()

    if (currentNode) {
      const children = FS.readdirSync(currentNode.path);

      for (let child of children) {
        const childPath = `${currentNode.path}/${child}`
        const childNode = new TreeNode(childPath)
        currentNode.children.push(childNode)

        // push to the stack if it is a directory
        if (FS.statSync(childNode.path).isDirectory()) {
          stack.push(childNode)
        }
      }
    }
  }
  //return the top root
  return root
}


//recursively prints the tree in required fashion, space variable for indentation
const printer = (tree, space) => {
	let s = ""
	for(let i=0;i<space;i++) s+= " "

  //print the tree to console
	console.log(s , '|-- ', tree['name'])

  // if current node has no more children return, i.e in case of file or empty directory
	if(!tree.hasOwnProperty('children')) return

  //if the curent node has children, recursively call for all children
	tree['children'].forEach((each_child) => {
		printer(each_child, space+2)
	})
}

//traverses the tree to fins the desired sub folder
const traverse = (tree, subFolder) => {
  if(!tree) {
    console.log('Not found')
    return
  }
  //if a match for subFolder found
  if(tree['name'].includes(subFolder)) {
    printer(tree,0)
    return
  }
  //recursively call for all children
  tree['children'].forEach(each_child => {
    traverse(each_child, subFolder)
  })
}

//take input from the user
const userInput = prompt('Enter relative path  : ')

//separate input into meaningful parts
const pathName = userInput.split(' ')[0]
const subFolder = userInput.split(' ')[1]

//absolute path of the folder
const pathoffolder = PATH.join(__dirname, pathName)

if(!FS.existsSync(pathoffolder)) {
  // if path provided does not exist
  console.log('Given path doesn\'t exist')
} else {
  //build the tree
  const tree = buildTree(pathoffolder)

  //check for sub folder filter
  if(subFolder === 'NULL' || subFolder === undefined) {
    printer(tree, 0)
  } else {
    traverse(tree, subFolder)
  }
}
