const PATH = require('path')
const FS = require('fs')
const prompt = require('prompt-sync')()

class TreeNode {
  constructor(path) {
    this.path = path
    this.name = PATH.basename(path)
    this.type = FS.statSync(path).isDirectory() ? 'Dir' : 'File'
    this.children = []
  }
}

const matchFilter = (filter, name) => name.includes(filter)

const  buildTree = (rootPath, fileFilter) => {
  const root = new TreeNode(rootPath)

  const stack = [root]

  while (stack.length) {
    const currentNode = stack.pop()

    if (currentNode) {
      const children = FS.readdirSync(currentNode.path);

      for (let child of children) {
        const childPath = `${currentNode.path}/${child}`
        const childNode = new TreeNode(childPath)

        if(FS.statSync(childNode.path).isDirectory()) {
          currentNode.children.push(childNode)
          stack.push(childNode)
        } else {
          if(fileFilter !== 'NULL') {
            if(childNode.name.includes(fileFilter)) {
              currentNode.children.push(childNode)
            }
          }
          else currentNode.children.push(childNode)
        }
      }
    }
  }

  return root
}

const printer = (tree, space) => {
	let s = ""
	for(let i=0;i<space;i++) s+= " "
	if(tree['type'] === 'Dir') {
    if(tree['children'].length) {
      console.log(s , '|-- ', tree['name'])
    }
  } else {
    console.log(s , '|-- ', tree['name'])
  }
	if(!tree.hasOwnProperty('children')) return
	tree['children'].forEach((each_child) => {
		printer(each_child, space+2)
	})
}

const traverse = (tree, subFolder) => {
  if(!tree) {
    console.log('Not found')
    return
  }
  if(tree['name'] === subFolder) {
    printer(tree,0)
    return
  }
  tree['children'].forEach(each_child => {
    traverse(each_child, subFolder)
  })
}

console.log('Input format: Path <space> Subfolder (or NULL) <space> FileFilter (or NULL)')
const userInput = prompt('Enter relative path and filters : ')

const pathName = userInput.split(' ')[0]
const subFolder = userInput.split(' ')[1]
const fileFilter = userInput.split(' ')[2]

const pathoffolder = PATH.join(__dirname, pathName)

if(!FS.existsSync(pathoffolder)) {
  console.log('Given path doesn\'t exist')
} else {
  const tree = buildTree(pathoffolder, fileFilter)
  if(subFolder === 'NULL') {
    printer(tree, 0)
  } else {
    traverse(tree, subFolder)
  }
}
